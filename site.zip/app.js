// GeoLog Pro Web App
// Minimal slippy map + samples + print forms
(function(){
  const $ = (s, r=document)=>r.querySelector(s);
  const $$ = (s, r=document)=>Array.from(r.querySelectorAll(s));
  const state = {
    theme: localStorage.getItem('gl:theme') || 'dark',
    map: { lat: 43.238949, lon: 76.889709, z: 10, tiles: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png' },
    samples: JSON.parse(localStorage.getItem('gl:samples')||'[]'),
    photos: null, // IDB
  };

  // Theme
  document.documentElement.setAttribute('data-theme', state.theme);
  $('#themeBtn').onclick = () => {
    state.theme = (state.theme === 'light' ? 'dark' : 'light');
    document.documentElement.setAttribute('data-theme', state.theme);
    localStorage.setItem('gl:theme', state.theme);
  };

  // PWA install prompt
  let deferredPrompt = null;
  window.addEventListener('beforeinstallprompt', (e)=>{
    e.preventDefault();
    deferredPrompt = e;
    $('#installBtn').hidden = false;
  });
  $('#installBtn').onclick = async ()=>{
    if(deferredPrompt){ deferredPrompt.prompt(); deferredPrompt = null; $('#installBtn').hidden = true; }
  };

  // Tabs
  $$('.tab').forEach(btn=> btn.onclick = ()=>{
    $$('.tab').forEach(b=> b.classList.remove('active'));
    btn.classList.add('active');
    $$('main > section').forEach(s=> s.hidden = true);
    $('#tab-'+btn.dataset.tab).hidden = false;
    if(btn.dataset.tab==='report') refreshReport();
    if(btn.dataset.tab==='samples') renderList();
  });

  // Service Worker
  if('serviceWorker' in navigator){
    navigator.serviceWorker.register('./sw.js');
  }

  // IndexedDB for photos
  let idb, store;
  const openIDB = () => new Promise((resolve,reject)=>{
    const req = indexedDB.open('geolog-pro', 1);
    req.onupgradeneeded = (e)=>{
      const db = e.target.result;
      db.createObjectStore('photos');
    };
    req.onsuccess = ()=>{
      idb = req.result;
      store = ()=> idb.transaction('photos', 'readwrite').objectStore('photos');
      resolve();
    };
    req.onerror = ()=> reject(req.error);
  });
  openIDB();

  // ---- Slippy Map ----
  const map = $('#map');
  const tilesDiv = document.createElement('div');
  tilesDiv.style.position = 'absolute';
  tilesDiv.style.left = '0'; tilesDiv.style.top='0'; tilesDiv.style.width='100%'; tilesDiv.style.height='100%';
  map.appendChild(tilesDiv);

  let view = { lat: state.map.lat, lon: state.map.lon, z: state.map.z, ox:0, oy:0 };
  let dragging = false, lastX=0, lastY=0;

  function lon2x(lon){ return (lon + 180) / 360; }
  function lat2y(lat){ const s = Math.sin(lat * Math.PI/180); return (0.5 - Math.log((1+s)/(1-s)) / (4*Math.PI)); }
  function x2lon(x){ return x*360 - 180; }
  function y2lat(y){ const n = Math.PI - 2*Math.PI*y; return 180/Math.PI * Math.atan(0.5*(Math.exp(n)-Math.exp(-n))); }
  function project(lat, lon, z){
    const n = Math.pow(2, z);
    const x = lon2x(lon) * n * 256;
    const y = lat2y(lat) * n * 256;
    return {x,y};
  }
  function unproject(px, py, z){
    const n = Math.pow(2, z) * 256;
    const x = px / n, y = py / n;
    return { lat: y2lat(y), lon: x2lon(x) };
  }

  function renderTiles(){
    const rect = map.getBoundingClientRect();
    const w = rect.width, h = rect.height;
    const center = project(view.lat, view.lon, view.z);
    const originX = center.x - w/2 - view.ox;
    const originY = center.y - h/2 - view.oy;
    const x0 = Math.floor(originX / 256);
    const y0 = Math.floor(originY / 256);
    const cols = Math.ceil(w/256)+2;
    const rows = Math.ceil(h/256)+2;
    tilesDiv.innerHTML = '';
    for(let r=0;r<rows;r++){
      for(let c=0;c<cols;c++){
        let x = x0 + c, y = y0 + r;
        const max = Math.pow(2, view.z);
        // wrap X, clamp Y
        const tx = ((x % max) + max) % max;
        if(y<0 || y>=max) continue;
        const url = state.map.tiles.replace('{z}', view.z).replace('{x}', tx).replace('{y}', y);
        const img = document.createElement('img');
        img.src = url;
        img.className = 'tile';
        img.style.left = (x*256 - originX) + 'px';
        img.style.top = (y*256 - originY) + 'px';
        tilesDiv.appendChild(img);
      }
    }
    // Markers
    $$('.marker', tilesDiv).forEach(m=> m.remove());
    for(const s of state.samples){
      if(!isFinite(s.lat)||!isFinite(s.lon)) continue;
      const p = project(s.lat, s.lon, view.z);
      const x = p.x - originX, y = p.y - originY;
      if(x<-40||y<-40||x>rect.width+40||y>rect.height+40) continue;
      const m = document.createElement('div');
      m.className = 'marker';
      m.style.left = x+'px'; m.style.top = y+'px';
      m.innerHTML = `<div class="pin">📍</div>`;
      m.title = s.title || 'Проба';
      m.onclick = ()=> openEditor(s.id);
      tilesDiv.appendChild(m);
    }
  }

  function setCenter(lat, lon){ view.lat=lat; view.lon=lon; view.ox=0; view.oy=0; renderTiles(); }
  function setZoom(z){
    z = Math.max(3, Math.min(18, z));
    // keep center stable
    const center = project(view.lat, view.lon, view.z);
    const geo = unproject(center.x, center.y, z);
    view.z = z; view.lat = geo.lat; view.lon = geo.lon; view.ox=0; view.oy=0; renderTiles();
  }

  renderTiles();
  window.addEventListener('resize', renderTiles);

  // Drag
  const startDrag = (x,y)=>{ dragging=true; lastX=x; lastY=y; };
  const moveDrag = (x,y)=>{
    if(!dragging) return;
    const dx=x-lastX, dy=y-lastY;
    view.ox -= dx; view.oy -= dy;
    lastX=x; lastY=y;
    // When offset exceeds tile, adjust center
    if(Math.abs(view.ox) > 256 || Math.abs(view.oy) > 256){
      const center = project(view.lat, view.lon, view.z);
      const nx = center.x + view.ox;
      const ny = center.y + view.oy;
      const geo = unproject(nx, ny, view.z);
      view.lat = geo.lat; view.lon = geo.lon; view.ox=0; view.oy=0;
    }
    renderTiles();
  };
  const endDrag = ()=>{ dragging=false; };

  map.addEventListener('pointerdown', e=>{ map.setPointerCapture(e.pointerId); startDrag(e.clientX, e.clientY); });
  map.addEventListener('pointermove', e=> moveDrag(e.clientX, e.clientY));
  map.addEventListener('pointerup', endDrag);
  map.addEventListener('pointercancel', endDrag);
  map.addEventListener('wheel', e=>{ e.preventDefault(); setZoom(view.z + (e.deltaY<0 ? 1 : -1)); }, {passive:false});

  // Controls
  $('#zoomIn').onclick = ()=> setZoom(view.z+1);
  $('#zoomOut').onclick = ()=> setZoom(view.z-1);

  // Geolocation
  $('#locBtn').onclick = ()=>{
    if(!navigator.geolocation) return alert('Геолокация не поддерживается');
    navigator.geolocation.getCurrentPosition(pos=>{
      setCenter(pos.coords.latitude, pos.coords.longitude);
    }, err=> alert('Ошибка геолокации: '+err.message), { enableHighAccuracy:true, timeout:8000 });
  };
  $('#addFromGPS').onclick = ()=>{
    if(!navigator.geolocation) return alert('Геолокация не поддерживается');
    navigator.geolocation.getCurrentPosition(pos=>{
      const s = makeSample({
        lat: +pos.coords.latitude.toFixed(6),
        lon: +pos.coords.longitude.toFixed(6),
        ele: pos.coords.altitude ? Math.round(pos.coords.altitude) : null
      });
      state.samples.push(s); persist();
      openEditor(s.id);
      renderTiles(); renderList(); refreshReport();
    }, err=> alert('Ошибка геолокации: '+err.message), { enableHighAccuracy:true, timeout:8000 });
  };

  // Prefetch tiles around current view
  $('#prefetch').onclick = async ()=>{
    const center = project(view.lat, view.lon, view.z);
    const rect = map.getBoundingClientRect();
    const w = rect.width, h=rect.height;
    const originX = center.x - w/2;
    const originY = center.y - h/2;
    const x0 = Math.floor(originX/256), y0=Math.floor(originY/256);
    const cols=Math.ceil(w/256)+4, rows=Math.ceil(h/256)+4;
    const zs = [view.z-1, view.z, view.z+1].filter(z=>z>=3 && z<=18);
    let count=0;
    for(const z of zs){
      const dx = Math.round((view.z - z));
      const scale = Math.pow(2, dx);
      const max = Math.pow(2, z);
      for(let r=0;r<rows;r++){
        for(let c=0;c<cols;c++){
          let x = Math.floor((x0 + c)/scale), y = Math.floor((y0 + r)/scale);
          const tx = ((x % max) + max) % max;
          if(y<0||y>=max) continue;
          const url = state.map.tiles.replace('{z}', z).replace('{x}', tx).replace('{y}', y);
          try{ await fetch(url, {mode:'no-cors'}); count++; }catch(e){}
          if(count>400){ break; }
        }
        if(count>400) break;
      }
    }
    alert('Загружено тайлов: ~'+count+' (часть могла быть уже в кеше)');
  };

  // ---- Samples CRUD ----
  function makeSample(p={}){
    return {
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
      title: p.title||'',
      lat: p.lat ?? NaN,
      lon: p.lon ?? NaN,
      ele: p.ele ?? null,
      head: p.head ?? null,
      depth: p.depth ?? null,
      lith: p.lith || '',
      notes: p.notes || '',
      photos: [] // keys in IDB
    };
  }

  function persist(){
    localStorage.setItem('gl:samples', JSON.stringify(state.samples));
  }

  function renderList(){
    const ul = $('#sampleList'); ul.innerHTML='';
    const q = ($('#search').value || '').trim().toLowerCase();
    const items = state.samples.filter(s => !q || (s.title+s.lith+s.notes).toLowerCase().includes(q));
    for(const s of items){
      const li = $('#sampleItemTpl').content.firstElementChild.cloneNode(true);
      $('.title', li).textContent = s.title || ('Проба ' + s.id.slice(0,8));
      $('.sub', li).textContent = `${fmt(s.createdAt)} • ${isFinite(s.lat)?s.lat.toFixed(6):'—'}, ${isFinite(s.lon)?s.lon.toFixed(6):'—'}`;
      $('.editBtn', li).onclick = ()=> openEditor(s.id);
      $('.delBtn', li).onclick = ()=>{ if(confirm('Удалить пробу?')){ removeSample(s.id);} };
      ul.appendChild(li);
    }
  }
  $('#search').oninput = renderList;
  $('#addSample').onclick = ()=>{ const s = makeSample(); state.samples.push(s); persist(); renderList(); openEditor(s.id); };

  function removeSample(id){
    const s = state.samples.find(x=>x.id===id);
    if(!s) return;
    // delete photos
    if(store){
      const tx = store();
      for(const k of s.photos){ tx.delete(k); }
      tx.transaction.oncomplete = ()=>{};
    }
    state.samples = state.samples.filter(x=>x.id!==id);
    persist(); renderList(); renderTiles(); refreshReport();
  }

  // Editor modal
  function openEditor(id){
    const s = state.samples.find(x=>x.id===id);
    if(!s) return;
    $('#editor').hidden=false;
    $('#e_title').value = s.title||'';
    $('#e_date').value = fmt(s.createdAt);
    $('#e_lat').value = isFinite(s.lat)?s.lat:'';
    $('#e_lon').value = isFinite(s.lon)?s.lon:'';
    $('#e_ele').value = s.ele??'';
    $('#e_head').value = s.head??'';
    $('#e_depth').value = s.depth??'';
    $('#e_lith').value = s.lith||'';
    $('#e_notes').value = s.notes||'';
    renderThumbs(s);
    $('#e_cancel').onclick = ()=> $('#editor').hidden=true;
    $('#e_save').onclick = ()=>{
      s.title = $('#e_title').value.trim();
      s.createdAt = parseDate($('#e_date').value) || s.createdAt;
      s.lat = parseFloat($('#e_lat').value); if(Number.isNaN(s.lat)) s.lat = NaN;
      s.lon = parseFloat($('#e_lon').value); if(Number.isNaN(s.lon)) s.lon = NaN;
      s.ele = valOrNull($('#e_ele').value);
      s.head = valOrNull($('#e_head').value);
      s.depth = valOrNull($('#e_depth').value);
      s.lith = $('#e_lith').value.trim();
      s.notes = $('#e_notes').value.trim();
      persist(); $('#editor').hidden=true; renderList(); renderTiles(); refreshReport();
    };
  }
  function valOrNull(v){ v=v.trim(); if(v==='') return null; const n=+v; return isFinite(n)?n:null }
  function fmt(iso){ const d = new Date(iso); return d.toLocaleString(); }
  function parseDate(s){ const d = new Date(s); return isNaN(d.getTime()) ? null : d.toISOString(); }

  function renderThumbs(s){
    const box = $('#e_photos'); box.innerHTML='';
    if(!s.photos || s.photos.length===0){ box.innerHTML = '<div class="muted">Фото нет</div>'; return; }
    const tx = idb.transaction('photos'); const os = tx.objectStore('photos');
    s.photos.forEach(k=>{
      const req = os.get(k);
      req.onsuccess = ()=>{
        const url = URL.createObjectURL(req.result);
        const img = document.createElement('img'); img.src = url;
        img.onclick = ()=> window.open(url, '_blank');
        box.appendChild(img);
      };
    });
  }

  // Add photo
  $('#addPhoto').onchange = (e)=>{
    const file = e.target.files[0];
    if(!file) return;
    const current = state.samples[state.samples.length-1];
    if(!current){ alert('Сначала создайте пробу'); return; }
    const k = crypto.randomUUID();
    const tx = store();
    const putReq = tx.put(file, k);
    putReq.onsuccess = ()=>{
      current.photos.push(k); persist();
      openEditor(current.id);
    };
    e.target.value='';
  };

  // CSV Export
  $('#exportCSV').onclick = ()=>{
    const header = "id,createdAt,title,lat,lon,ele,head,depth,lith,notes,photosCount";
    const lines = state.samples.map(s=>{
      const esc = v => ('"'+String(v).replace(/"/g,"'")+'"');
      return [s.id, s.createdAt, esc(s.title||''), isFinite(s.lat)?s.lat:'', isFinite(s.lon)?s.lon:'', s.ele??'', s.head??'', s.depth??'', esc(s.lith||''), esc(s.notes||''), s.photos.length].join(',');
    });
    const blob = new Blob([header+'\n'+lines.join('\n')], {type:'text/csv;charset=utf-8'});
    download('samples.csv', blob);
  };

  // Batch "PDF" -> print
  $('#batchPrint').onclick = ()=>{
    openPrintable('batch');
  };

  // Report summary
  function refreshReport(){
    $('#kTotal').textContent = state.samples.length;
    $('#kWithPhotos').textContent = state.samples.filter(s=>s.photos.length>0).length;
    const table = document.createElement('table');
    table.innerHTML = '<thead><tr><th>Проба</th><th>Дата</th><th>Координаты</th><th>Литология</th></tr></thead>';
    const tbody = document.createElement('tbody');
    for(const s of state.samples.slice(-5)){
      const tr = document.createElement('tr');
      tr.innerHTML = `<td>${s.title||('Проба '+s.id.slice(0,8))}</td><td>${fmt(s.createdAt)}</td><td>${isFinite(s.lat)?s.lat.toFixed(6):'—'}, ${isFinite(s.lon)?s.lon.toFixed(6):'—'}</td><td>${s.lith||''}</td>`;
      tbody.appendChild(tr);
    }
    table.appendChild(tbody);
    const box = $('#last5'); box.innerHTML=''; box.appendChild(table);
  }
  refreshReport();

  // Printable forms
  $('#openPrintable').onclick = ()=> openPrintable('report');
  $('#printPassport').onclick = ()=> openPrintable('passport');
  $('#printJournal').onclick = ()=> openPrintable('journal');

  function openPrintable(mode){
    const w = window.open('', '_blank');
    const s = state.samples[state.samples.length-1];
    const styles = document.querySelector('style')?.outerHTML || '';
    const body = [];
    body.push('<div class="print" id="print">');
    if(mode==='report' || mode==='batch'){
      body.push(`<h2>Сводный отчёт (последние ${state.samples.length} проб)</h2>`);
      body.push(`<div>Сформировано: ${fmt(new Date().toISOString())}</div>`);
      body.push(`<div class="box">Всего проб: ${state.samples.length}. С фото: ${state.samples.filter(x=>x.photos.length>0).length}.</div>`);
      body.push('<table border="1" cellspacing="0" cellpadding="4" width="100%"><thead><tr><th>№</th><th>ID/Название</th><th>Дата</th><th>Коорд.</th><th>Высота</th><th>Глубина</th><th>Литология</th><th>Примечания</th></tr></thead><tbody>');
      state.samples.forEach((s,i)=>{
        body.push(`<tr><td>${i+1}</td><td>${s.title||s.id.slice(0,8)}</td><td>${fmt(s.createdAt)}</td><td>${isFinite(s.lat)?s.lat.toFixed(6):'—'}, ${isFinite(s.lon)?s.lon.toFixed(6):'—'}</td><td>${s.ele??''}</td><td>${s.depth??''}</td><td>${s.lith||''}</td><td>${s.notes||''}</td></tr>`);
      });
      body.push('</tbody></table>');
      if(mode==='report'){ body.push('<script>setTimeout(()=>window.print(),500);<\/script>'); }
    }
    if(mode==='passport'){
      if(!s){ body.push('<div>Нет текущей пробы</div>'); }
      else{
        body.push(`<h2>Паспорт пробы</h2>`);
        body.push(`<div class="box"><b>ID:</b> ${s.id}<br><b>Название:</b> ${s.title||''}<br><b>Дата:</b> ${fmt(s.createdAt)}<br><b>Координаты:</b> ${isFinite(s.lat)?s.lat.toFixed(6):'—'}, ${isFinite(s.lon)?s.lon.toFixed(6):'—'}<br><b>Высота:</b> ${s.ele??''} м&nbsp;&nbsp;<b>Азимут:</b> ${s.head??''}°&nbsp;&nbsp;<b>Глубина:</b> ${s.depth??''} м<br><b>Литология:</b> ${s.lith||''}<br><b>Заметки:</b> ${s.notes||''}</div>`);
        body.push(`<div class="box"><b>Подписи:</b><br><br>Отборщик: ____________  Дата: ____________<br>Контроль: ____________  Дата: ____________</div>`);
        body.push('<script>setTimeout(()=>window.print(),500);<\/script>');
      }
    }
    if(mode==='journal'){
      body.push(`<h2>Журнал отбора проб</h2>`);
      body.push('<table border="1" cellspacing="0" cellpadding="4" width="100%"><thead><tr><th>№</th><th>ID/Название</th><th>Дата</th><th>Координаты</th><th>Литология</th><th>Примечания</th><th>Подпись</th></tr></thead><tbody>');
      state.samples.forEach((s,i)=>{
        body.push(`<tr><td>${i+1}</td><td>${s.title||s.id.slice(0,8)}</td><td>${fmt(s.createdAt)}</td><td>${isFinite(s.lat)?s.lat.toFixed(6):'—'}, ${isFinite(s.lon)?s.lon.toFixed(6):'—'}</td><td>${s.lith||''}</td><td>${s.notes||''}</td><td></td></tr>`);
      });
      body.push('</tbody></table>');
      body.push('<script>setTimeout(()=>window.print(),500);<\/script>');
    }
    body.push('</div>');
    w.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>Печать</title><style>${document.querySelector('link[href="style.css"]')? '': ''}</style><style>${document.querySelector('style')?.textContent||''}</style><style>@media print {.print{display:block}}</style></head><body>${body.join('')}</body></html>`);
    w.document.close();
  }

  // CSV import
  $('#csvImport').onchange = (e)=>{
    const file = e.target.files[0]; if(!file) return;
    const reader = new FileReader();
    reader.onload = ()=>{
      const lines = String(reader.result).trim().split(/\r?\n/);
      for(let i=0;i<lines.length;i++){
        if(i===0 && lines[i].toLowerCase().includes('title')) continue;
        const [title,lat,lon,depth,lith,notes] = lines[i].split(',');
        const s = makeSample({ title, lat:+lat, lon:+lon, depth: valOrNull(depth||''), lith: (lith||'').trim(), notes:(notes||'').trim() });
        state.samples.push(s);
      }
      persist(); renderList(); renderTiles(); refreshReport();
      e.target.value='';
    };
    reader.readAsText(file);
  };

  // Install theme toggle label on reload (UX)
  const mq = window.matchMedia('(display-mode: standalone)');
  if(mq.matches){ $('#installBtn').hidden = true; }

  // Render initial list
  renderList();

  // Helpers
  function download(name, blob){
    const a = document.createElement('a');
    const url = URL.createObjectURL(blob);
    a.href = url; a.download = name; a.click();
    setTimeout(()=> URL.revokeObjectURL(url), 1500);
  }
})();
