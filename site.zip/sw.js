// GeoLog Pro Web Service Worker
const CACHE_NAME = 'geolog-pro-v1';
const APP_SHELL = [
  './',
  './index.html',
  './style.css',
  './app.js',
  './manifest.webmanifest',
  './icons/icon-192.png',
  './icons/icon-512.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(APP_SHELL))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(keys.map(k => k === CACHE_NAME ? null : caches.delete(k))))
  );
  self.clients.claim();
});

// Simple LRU for tiles via headers
async function cacheFetch(request) {
  const url = new URL(request.url);
  const isTile = url.hostname.includes('tile.openstreetmap.org');
  if (!isTile) {
    const cached = await caches.match(request);
    return cached || fetch(request);
  }
  // Tiles: try cache first, else network then cache
  const cache = await caches.open('tiles-v1');
  const cached = await cache.match(request);
  if (cached) return cached;
  const resp = await fetch(request);
  if (resp.ok) {
    cache.put(request, resp.clone());
  }
  return resp;
}

self.addEventListener('fetch', (event) => {
  event.respondWith(cacheFetch(event.request));
});
